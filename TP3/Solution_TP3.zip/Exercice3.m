%*******************************************************************
%FICHIER:     TP3-Erxercice3.m                                     *
%DESCRIPTION: Tri par InsertionSort								   *
%                                                                  * 
%AUTEUR:      Olivier Grenier-Ch�nier                              *
%CREATION:    2019-02-10                                           *
%*******************************************************************
clear all; clc;

shuffled = randperm(50);

sorted = shuffled;

tic();

% Impl�mentation de l'algorithme InsertionSort
% https://en.wikipedia.org/wiki/Insertion_sort
i = 1;
while i <= length(sorted)
    j = i;
    while j > 1 && sorted(j-1) > sorted(j)
        tmp = sorted(j-1);
        sorted(j-1) = sorted(j);
        sorted(j) = tmp;        
        j = j-1;
    end
    i = i + 1;
end

t1 = toc();
fprintf('Temps d''ex�cution de InsertionSort : %.2f us\n', t1*1000*1000);

% Mesure du temps d'ex�cution de la fonction sort()
tic();
s = sort(shuffled);
t2 = toc();

fprintf('Temps d''ex�cution de sort() : %.2f us\n', t2*1000*1000);



