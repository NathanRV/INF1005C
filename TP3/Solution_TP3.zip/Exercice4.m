%**********************************************************************
%FICHIER:     TP3-Exercice4.m                                         *
%DESCRIPTION: Jeu de cartes � Sp�cial 8 �                      		  *
%                                                                     * 
%AUTEUR:      Serge Ouedraogo                                         *
%CREATION:    09 Fevrier 2019                                         *
%                                                                     *
%**********************************************************************
clear all ; clc;

fprintf('***"Bienvenue au Jeu de cartes "Sp�cial 8"***\n\n');

% Sp�cification du nombre de joueurs
Nb_joueur=input('Entrez le nombre de joueurs dans la partie : ');
while Nb_joueur<2 || 5<Nb_joueur
    Nb_joueur=input('Entrez le nombre de joueurs dans la partie compris entre 2 et 5 joueurs : ');
end

% Cr�ation des joueurs
for i=1:Nb_joueur
    joueur(i).id=num2str(i);
    joueur(i).points=0;
    joueur(i).cartes={};
end

Type_cartes={'as' '2' '3' '4' '5' '6' '7' '8' '9' '10' 'valet' 'dame' 'roi'};
Couleur_cartes={'Pique' 'Trefle' 'Coeur' 'Carreau'};

carrtes = cell(52,2); %Total des cartes dans le Jeu
t=1;
for i=1:13
    for j=1:4
        carrtes(t,:)= {Type_cartes{i} Couleur_cartes{j}} ;
        t=t+1;
    end
end

%Creation du Talon
pioche = carrtes(randperm(52),:);

%Distribution des cartes aux joueurs
nbpartage = input('Entrez le nombre de cartes � distribuer � chaque joueur : ');

while nbpartage<3 || 8<nbpartage
    nbpartage = input('Entrez le nombre de cartes � distribuer � chaque joueur (compris entre 3 et 8) : ');
end

for i=1:Nb_joueur
    for j=1:nbpartage
        joueur(i).cartes(j,1) = {pioche(1,:)};
        pioche(1,:)=[];
    end
end

%Initialisation de la table
table(1,:)=pioche(1,:);
pioche(1,:)=[];
terminer = false;

for w=1:3
    for i=1:Nb_joueur
        ajouer=false;
        while(~ajouer)
            fprintf('\n** Menu Joueur %s **\n',joueur(i).id);
            fprintf(' 1- Voir vos cartes \n 2- Jouer une carte\n 3- Piocher\n');
            choix=0;
            while choix<1 || choix>3
                choix=input('Choix : ');
            end
            
            
            switch choix
                case 1
                    %Affichage des cartes
                    fprintf('Voici vos cartes :  \n');
                    t_carte=length(joueur(i).cartes);
                    
                    for k=1:t_carte
                        fprintf('Carte %d : "%s" "%s"\n',k,joueur(i).cartes{k,1}{1,1},joueur(i).cartes{k,1}{1,2});
                    end
                    fprintf('\n>La Carte : "%s" de "%s" est sur la table.\n',table{end,1},table{end,2});
                    
                    ajouer=false;
                case 2
                    %Jouer une carte
                    fprintf('\n>La Carte : "%s" de "%s" est sur la table.\n',table{end,1},table{end,2});
                    fprintf('\nChoisissez une carte � jouer :  \n');
                    t_carte=length(joueur(i).cartes);
                    
                    for k=1:t_carte
                        fprintf('Carte %d : "%s" "%s"\n',k,joueur(i).cartes{k,1}{1,1},joueur(i).cartes{k,1}{1,2});
                    end
                    num_cart = 0;
                    while num_cart<1 || num_cart>t_carte
                        num_cart = input ('Num�ro de la carte � jouer : ');
                    end
                    
                    cart=joueur(i).cartes{num_cart,1};
                    
                    % Si m�me couleur, ou m�me type, ou est un '8'
                    if strcmp(cart{1,1},table{end,1}) || strcmp(cart{1,2},table{end,2}) || strcmp(cart{1,1},'8')
                        
                        table(end+1,:)=cart;
                        joueur(i).cartes(num_cart)=[];
                        ajouer = true;
                        
						% Un '2' fait piger deux cartes au joueur suivant.
                        if strcmp(cart{1,1},'2')
                            fprintf('P�nalit� de deux cartes pour le joueur suivant.\n');
                            if i==Nb_joueur
                                if size(pioche,1)>=2
                                    joueur(1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];
                                    joueur(1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];           
                                elseif size(pioche,1)>=1
                                    joueur(1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];
                                else
                                    fprintf('La pioche est vide!\n');
                                    
                                end
                                
                            else
                                if size(pioche,1)>=2
                                    joueur(i+1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];
                                    joueur(i+1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];
                                elseif size(pioche,1)>=1                               
                                    joueur(i+1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];
                                else
                                    fprintf('La pioche est vide!\n');
                                    
                                end
                                
                            end
							
						% Un 'as fait piger une carte au joueur suivant.
                        elseif strcmp(cart{1,1},'as')
                            fprintf('P�nalit� d''une carte pour le joueur suivant.\n');
                            
                            if i==Nb_joueur
                                
                                
                                
                                if size(pioche,1)>=1
                                    joueur(1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];
                                else
                                    fprintf('La pioche est vide!\n');
                                    
                                end
                                
                                
                            else
                                
                                if size(pioche,1)>=1
                                    joueur(i+1).cartes(end+1,1) = {pioche(1,:)};
                                    pioche(1,:)=[];
                                else
                                    fprintf('La pioche est vide!\n');
                                end
                                
                                
                            end
                        end
                        
                    else
                        %Carte invalide. Faire piocher 2 cartes
                        fprintf('Erreur dans le jeu. P�nalit� de deux cartes !\n');
                        ajouer = true;
                        
                        if size(pioche,1)>=2
                            joueur(i).cartes(end+1,1) = {pioche(1,:)};
                            pioche(1,:)=[];
                            joueur(i).cartes(end+1,1) = {pioche(1,:)};
                            pioche(1,:)=[];
                            
                        elseif size(pioche,1)>=1
                            joueur(i).cartes(end+1,1) = {pioche(1,:)};
                            pioche(1,:)=[]; 
                        else
                            fprintf('La pioche est vide!\n');
                        end
                        
                    end
                    
                case 3
                    %Piocher une carte
                    %Talon vide = aucune carte piocher
                    if size(pioche,1)>=1
                        joueur(i).cartes(end+1,1)= {pioche(1,:)};
                        pioche(1,:)=[];
                        fprintf('Vous avez piocher une carte.\n');
                    else
                        fprintf('La pioche est vide!\n');
                        
                    end
                    ajouer=true;                  
            end
        end
    end
end

%Comptage des Points
imin=1;
for i=1:Nb_joueur
    
    t_carte=length(joueur(i).cartes);
    while (t_carte>0)
        
        valeur = joueur(i).cartes{t_carte,1}{1,1};
        
        switch valeur
            case {'as','valet'} 
                joueur(i).points=joueur(i).points+11;
            case {'roi','dame'}            
                joueur(i).points=joueur(i).points+5;
            case '8'
                joueur(i).points=joueur(i).points+32;
            case '2'
                joueur(i).points=joueur(i).points+20;
            case {'10','9','7','6','5','4','3'}
                joueur(i).points=joueur(i).points+str2num(valeur);
        end
        
        t_carte = t_carte-1;
    end
    
    
    fprintf('\nJoueur %d = %d points', i, joueur(i).points);
    
    if joueur(imin).points > joueur(i).points
        imin=i;
    end
    
end

fprintf('\n\nLe "Joueur %d" gagne la partie. Bravo !\n\n*****Fin de la partie*****\n\n', imin);



