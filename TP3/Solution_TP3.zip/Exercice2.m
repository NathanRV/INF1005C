%**********************************************************************
%FICHIER:     TP3-Exercice2.m                                         *
%DESCRIPTION: La Suite de Fibonacci                          		  *
%                                                                     * 
%AUTEUR:      Serge Ouedraogo                                         *
%CREATION:    09 Fevrier 2019                                         *
%                                                                     *
%**********************************************************************
clear all; clc;

continuer ='oui';

while (strcmpi(continuer, 'oui'))
    F=[];
    n=0;
    while (ischar(n) || n<3)
        n= input('Entrez le nombre n : ');
    end
    
    tic;
    
    F(1)=0;
    F(2)=1;
    n_pair=1;
    n_impair=1;
    n_prime=1; % On considere le chiffre 2 si n>3
    
    for i=2:n-1
        F(i+1)=F(i)+F(i-1);
        if mod(F(i+1),2)==0
            n_pair=n_pair+1;
        elseif mod(F(i+1),2)==1
            n_impair=n_impair+1;
            
            %Nombres premiers
            if (n>3)
                p=2;
                tst=-1;
                while(p<F(i+1))
                    if rem(F(i+1),p)==0
                        %Alors pas premier
                        p=F(i+1);
                        tst=1;
                    end
                    p=p+1;
                    
                    if (tst~=1 && p==F(i+1))
                        n_prime=n_prime+1;
                    end
                end
                
            else
                n_prime=0;
            end
            
        end  
       
    end
    
    temps=toc;
    
    fprintf('Suite de Fibonacci : ');
    fprintf('%d  ',F);
    fprintf('\n');
    fprintf('Le nombre de termes pairs: %d\n',n_pair);
    fprintf('Le nombre de termes impairs: %d\n',n_impair);
    fprintf('Le nombre de termes premiers: %d\n',n_prime);
    fprintf('Temps de calcul: %.4f secondes\n\n',temps);
    
    conti='';
    while (~strcmpi(conti, 'oui') &&  ~strcmpi(conti, 'non'))
        conti = input('Voulez-vous continuer ? : ', 's');
    end
    continuer = conti;
    
end
fprintf ('Au revoir!\n');
