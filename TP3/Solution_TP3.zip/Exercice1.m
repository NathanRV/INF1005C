%*******************************************************************
%FICHIER:     TP3-Erxercice1.m                                     *
%DESCRIPTION: Calcul d'une somme partielle                         *
%                                                                  * 
%AUTEUR:      LAMIA EL GAROUI                                      *
%CREATION:    2018-02-12                                           *
%MISE � JOUR: 2019-02-07                                           *
%*******************************************************************

clear all; clc;

% faire une boucle tant que la r�ponse est diff�rente de 0
continuer=1;
while continuer
    % entrer le nombre de termes � calculer
    nb=input('\nCombien de termes voulez-vous calculer? (faites le 0 pour quitter) ?  ');
    
    if isnumeric(nb) && nb > 0 && nb == round(nb)
        somme=0;
        for i=1:nb
            somme=somme+(1/((i+2)^i));
        end
        fprintf('La somme partielle des %d premiers termes est : %.12f \n', nb, somme);
    elseif nb==0
        continuer=0;
        fprintf('Merci, Au revoir !\n');
    else
        fprintf('Ce choix est invalide.\n');
    end
end
